function onAppLoaded()
{
	var forms = App.getForms();

	App.showForm(forms[0]);
}

function onAppClosing()
{
	
}